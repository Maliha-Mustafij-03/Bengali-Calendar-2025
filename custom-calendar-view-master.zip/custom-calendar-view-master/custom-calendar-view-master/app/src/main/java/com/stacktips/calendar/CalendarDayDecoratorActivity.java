package com.stacktips.calendar;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.HorizontalScrollView;

public class CalendarDayDecoratorActivity extends AppCompatActivity {

    private HorizontalScrollView horizontalScrollView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar_decorator);

        // Initialize HorizontalScrollView
        horizontalScrollView = findViewById(R.id.horizontalScrollView);

        // Optionally, you can programmatically scroll to a specific month if needed
        // Example: Scroll to June (Month index 5, since January is index 0)
        // scrollToMonth(5);
    }

    // Optionally add methods to scroll to a specific month programmatically
    private void scrollToMonth(int monthIndex) {
        // Get the position of the ImageView for the specified month
        int position = getResources().getIdentifier(getMonthImageViewId(monthIndex), "id", getPackageName());
        View monthView = findViewById(position);

        if (monthView != null) {
            horizontalScrollView.smoothScrollTo(monthView.getLeft(), 0);
        }
    }

    private String getMonthImageViewId(int monthIndex) {
        switch (monthIndex) {
            case 0:
                return "january";
            case 1:
                return "february";
            case 2:
                return "march";
            case 3:
                return "april";
            case 4:
                return "may";
            case 5:
                return "june";
            case 6:
                return "july";
            case 7:
                return "august";
            case 8:
                return "september";
            case 9:
                return "october";
            case 10:
                return "november";
            case 11:
                return "december";
            default:
                return "january"; // Default to January if invalid month
        }
    }
}
