package com.stacktips.calendar;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MonthImageActivity extends AppCompatActivity {

    private static final String[] MONTH_NOTES = {
            "জানুয়ারী: জানুয়ারী মাসে কোনো ছুটি নেই ",
            "ফেব্রুয়ারি: ১৫ ফেব্রুয়ারি (শনিবার): শবে বরাত \n" +
                    " ২১ ফেব্রুয়ারি (শুক্রবার): শহীদ দিবস ও আন্তর্জাতিক মাতৃভাষা দিবস ",
            "মার্চ:২৬ মার্চ (বুধবার):স্বাধীনতা দিবস\n" +
                    "২৮ মার্চ (শুক্রবার):জুমাতুল বিদা ও শব-ই-ক্বদর\n" +
                    "২৯ মার্চ (শনিবার):ঈদুল ফিতরের ২দিন আগের দিন \n"+
                    "৩০ মার্চ (রবিবার):ঈদুল ফিতরের আগের দিন \n"+
                    "৩১ মার্চ (সোমবার):ঈদুল ফিতর",
            "এপ্রিল:  ১ এপ্রিল (মঙ্গলবার): ঈদুল ফিতরের পরের দিন\n" +
                    "২ এপ্রিল (বুধবার): ঈদুল ফিতরের দ্বিতীয় দিন \n" +
                    "১৪ এপ্রিল (সোমবার):বাংলা নববর্ষ",
            "মে: ১ মে (বৃহস্পতিবার): মে দিবস\n" +
                    "১১ মে (রবিবার):বুদ্ধ পূর্ণিমা",
            "জুন: ৫ জুন (বৃহস্পতিবার): ঈদুল আজহার ২ দিন আগের দিন\n" +
                    " ৬ জুন (শুক্রবার): ঈদুল আজহার আগের দিন \n" +
                    " ৭ জুন (শনিবার): ঈদুল আজহা \n" +
                    " ৮ জুন (রবিবার): ঈদুল আজহার পরের দিন \n" +
                    " ৯ জুন (সোমবার): ঈদুল আজহার দ্বিতীয় দিন \n" +
                    " ১০ জুন (মঙ্গলবার): ঈদুল আজহার তৃতীয় দিন",
            "জুলাই: ৬ জুলাই (রবিবার): আশুরার দিন",
            "আগস্ট: ১৬ আগস্ট (শনিবার): জন্মাষ্টমী",
            "সেপ্টেম্বর: ৫ সেপ্টেম্বর (শুক্রবার): ঈদে মিলাদুন্নবী(সা.)",
            "অক্টোবর: ১ অক্টোবর (বুধবার): দুর্গাপূজা (নবমী) \n" +
                    "২ অক্টোবর (বৃহস্পতিবার): দুর্গাপূজা (বিজয়া দশমী)",

            "নভেম্বর: নভেম্বর মাসে কোনো ছুটি নেই "
            ,
            "ডিসেম্বর: ১৬ ডিসেম্বর (মঙ্গলবার): বিজয় দিবস\n" +
                    " ২৫ ডিসেম্বর (বৃহস্পতিবার): বড়দিন "
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_month_image);

        String month = getIntent().getStringExtra("month");

        ImageView imageView = findViewById(R.id.month_image);
        int imageResource = getResources().getIdentifier(month.toLowerCase(), "drawable", getPackageName());
        imageView.setImageResource(imageResource);

        // Set up the Go Back button
        Button goBackButton = findViewById(R.id.go_back_button);
        goBackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();  // This will close the current activity and go back to the previous one
            }
        });

        // Set up the note text box
        TextView noteTextView = findViewById(R.id.month_note);
        int monthIndex = getMonthIndex(month);
        if (monthIndex != -1) {
            noteTextView.setText(MONTH_NOTES[monthIndex]);
        }
    }

    private int getMonthIndex(String month) {
        switch (month.toLowerCase()) {
            case "january": return 0;
            case "february": return 1;
            case "march": return 2;
            case "april": return 3;
            case "may": return 4;
            case "june": return 5;
            case "july": return 6;
            case "august": return 7;
            case "september": return 8;
            case "october": return 9;
            case "november": return 10;
            case "december": return 11;
            default: return -1;
        }
    }
}
